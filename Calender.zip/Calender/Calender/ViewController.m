//
//  ViewController.m
//  Calender
//
//  Created by quadmini2 on 11/05/17.
//  Copyright © 2017 quadmini2. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    int month,year;
    UILabel *label;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    month = 1;
    year = 2017;

    NSDate *date = [[self returnDateFormatter] dateFromString:[NSString stringWithFormat:@"1/%d/%d",month,year]
                    ];
    int numberOfDays = [self numberOfdaysinMonth:month WithDate:date];
    int index =  [self weekDayForDate:date];

    [self createButtonsAndLablesForNumberOfDays:numberOfDays withStartingAtDay:index];
    // Do any additional setup after loading the view, typically from a nib.
}

- (NSDateFormatter *)returnDateFormatter {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    return dateFormatter;

}
-(int)numberOfdaysinMonth:(int)selectedMonthNumber WithDate:(NSDate *)selectedDate
{
    NSCalendar* cal = [NSCalendar currentCalendar];
    NSDateComponents* comps = [[NSDateComponents alloc] init];
    // Set your month here
    [comps setMonth:selectedMonthNumber];

    NSRange range = [cal rangeOfUnit:NSCalendarUnitDay
                              inUnit:NSCalendarUnitMonth
                             forDate:selectedDate];
    NSLog(@"%lu", (unsigned long)range.length);
    return (int)range.length;
}
-(long)weekDayForDate:(NSDate *)date
{
    NSCalendar* cal = [NSCalendar currentCalendar];
    NSDateComponents* comp = [cal components:NSCalendarUnitWeekday fromDate:date];
    return [comp weekday];

}
-(void)createButtonsAndLablesForNumberOfDays:(int)days withStartingAtDay:(int)startIndex
{

    for (UIView *v  in [_calendarScroll subviews])
    {
        [v removeFromSuperview];
    }
    int xpos = 0;
    int ypos = 0;
    for (int xcount =1; xcount<=7; xcount++)
    {
        if (xcount==startIndex)
        {
            break;
        }
        xpos = xpos+46;
    }

    for (int i = 1; i<=days; i++)
    {
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(xpos+5, ypos-5, 46, 33)];
        label.text=[NSString stringWithFormat:@"%d",i];
        label.font=[UIFont boldSystemFontOfSize:14.0];
        label.textColor=[UIColor colorWithRed:87/255.0 green:212/255.0 blue:218/255.0 alpha:1.0];
        [_calendarScroll addSubview:label];


        UIButton *dateButton = [UIButton buttonWithType:UIButtonTypeCustom];
        dateButton.frame = CGRectMake(xpos, ypos, 46, 33);


        //compare date to place marker over current date
        NSString *actualDate = [[NSString alloc]initWithFormat:@"%d/%d/%d",i,month,year];
        NSDate *date = [[self  returnDateFormatter] dateFromString:actualDate];
        NSString *todayDatestr= [[self returnDateFormatter] stringFromDate:[NSDate date]];
        NSDate *todayDate = [[self returnDateFormatter]dateFromString:todayDatestr];
        NSComparisonResult result = [date compare:todayDate];
        // compare date with today date to display current date
        if (result==NSOrderedSame)
        {
            [dateButton setImage:[UIImage imageNamed:@"dia_over.png"] forState:UIControlStateNormal];

        }
        dateButton.tag=i;
        //[dateButton addTarget:self action:@selector(dateSelected:) forControlEvents:UIControlEventTouchUpInside];
        [_calendarScroll addSubview:dateButton];
        xpos=xpos+46;
        startIndex=startIndex+1;

        if (startIndex==8)
        {
            xpos=0;
            ypos=ypos+33;
            startIndex=1;
        }

    }

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
