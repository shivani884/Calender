//
//  ViewController.h
//  Calender
//
//  Created by quadmini2 on 11/05/17.
//  Copyright © 2017 quadmini2. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIScrollView *calendarScroll;

@end

