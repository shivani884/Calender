//
//  main.m
//  Calender
//
//  Created by quadmini2 on 11/05/17.
//  Copyright © 2017 quadmini2. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
